n = int(input("Введите целое положительное число N: "))
total_sum = 0

for i in range(1, n + 1):
    total_sum += i

# Вывод в формате примера
print(f"Введено: {n}")
expression = " + ".join(str(i) for i in range(1, n + 1))
print(f"Результат: {expression} = {total_sum}")