even_count = 0
odd_count = 0
total_sum = 0

print("Введите 10 целых чисел:")
for _ in range(10):
    num = int(input())
    total_sum += num
    if num % 2 == 0:
        even_count += 1
    else:
        odd_count += 1

print("Количество чётных чисел:", even_count)
print("Количество нечётных чисел:", odd_count)
print("Сумма всех введённых чисел:", total_sum)