import random

secret_number = random.randint(1, 100)
attempts = 0

print("Я загадал число от 1 до 100. Попробуй угадать!")

while True:
    guess = int(input("Ваш вариант: "))
    attempts += 1
    
    if guess == secret_number:
        print(f"Поздравляю! Вы угадали число.")
        break
    elif guess < secret_number:
        print("Загаданное число больше")
    else:
        print("Загаданное число меньше")

print(f"Количество попыток: {attempts}")